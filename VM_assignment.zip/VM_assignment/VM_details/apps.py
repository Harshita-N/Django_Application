from django.apps import AppConfig


class VmDetailsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'VM_details'
