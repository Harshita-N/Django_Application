from django.http.response import HttpResponse
from django.shortcuts import render
from VM_details.models import Performance

# Create your views here.
#def home(request):
#    return HttpResponse("Hello World")

def showdata(request):
    results=Performance.objects.all()
    return render(request,'index.html', {'data' : results}) 
# Create your views here.


