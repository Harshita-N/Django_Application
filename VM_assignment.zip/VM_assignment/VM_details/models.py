from django.db import models

# Create your models here.
class Performance(models.Model):
    memory=models.CharField(max_length=50)
    disk=models.CharField(max_length=50)
    cpu=models.CharField(max_length=50)